import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-bestslip',
  templateUrl: 'bestslip.html'
})
export class BestslipPage {

  constructor(public navCtrl: NavController) {

  }

}
